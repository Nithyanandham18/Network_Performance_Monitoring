import threading
import time
import asyncio
import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse

from behavioral_classifier import (
    poll_process_io, dns_resolver, snapshot_and_detect,
    display_rows, recent_rootcauses, collector, lock, init_csv,
    engine, rce,
)

app = FastAPI(title="Network Monitor Daemon")


@app.on_event("startup")
def startup_event():
    print("Starting background engines...")
    init_csv()
    threading.Thread(target=poll_process_io,    daemon=True).start()
    threading.Thread(target=dns_resolver,        daemon=True).start()
    threading.Thread(target=snapshot_and_detect, daemon=True).start()
    collector.start()
    print("Engines running. Warming up 5 seconds...")
    time.sleep(5)
    print("Ready.")


@app.get("/")
async def get_dashboard():
    try:
        with open("index.html", "r") as f:
            return HTMLResponse(f.read())
    except FileNotFoundError:
        return HTMLResponse("<h2>index.html not found — place it alongside web_daemon.py</h2>")


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            # FIX: Serialise display_rows inside the lock so we get a consistent
            # snapshot. Convert every value to a plain Python primitive so
            # FastAPI's JSON encoder never chokes on unexpected types.
            with lock:
                flows = [
                    {
                        "pid":            int(r["pid"]),
                        "proc":           str(r["proc"]),
                        "kbps":           round(float(r["kbps"]), 1),
                        "avg_kbps":       round(float(r["avg_kbps"]), 1),
                        "classification": str(r["classification"]),
                        "severity":       int(r["severity"]),
                        "hostname":       str(r.get("hostname") or ""),
                    }
                    for r in list(display_rows)
                ]

                causes = [
                    {
                        "app":            str(rc.alert.app_class),
                        "proc":           str(rc.alert.proc),
                        "kbps":           round(float(rc.alert.current_kbps), 1),
                        "baseline_kbps":  round(float(rc.alert.baseline_kbps), 1),
                        "severity":       int(rc.alert.severity),
                        "cause":          str(rc.cause),
                        "confidence":     int(rc.confidence),
                        "recommendation": str(rc.recommendation),
                        "evidence":       [str(e) for e in rc.evidence[:3]],
                        "timestamp":      str(rc.timestamp),
                    }
                    for rc in list(recent_rootcauses)[:5]
                ]

            # FIX: Read snapshot outside the classifier lock — it has its own
            # internal lock inside SignalCollector.snapshot property
            snap = collector.snapshot
            signals = {
                "rtt_ms":          round(snap.rtt_ms, 1),
                "jitter_ms":       round(snap.jitter_ms, 1),
                "rtt_baseline_ms": round(snap.rtt_baseline_ms, 1),
                "rtt_jump":        bool(snap.rtt_jump),
                "rtt_sustained":   bool(snap.rtt_sustained_high),
                "retransmit_rate": round(snap.retransmit_rate, 2),
                "retransmit_high": bool(snap.retransmit_high),
                "dns_ms":          round(snap.dns_ms, 1),
                "dns_slow":        bool(snap.dns_slow),
                "wifi_pct":        int(snap.wifi_signal_pct),
                "wifi_weak":       bool(snap.wifi_weak),
                "cpu_pct":         round(snap.cpu_pct, 1),
                "cpu_high":        bool(snap.cpu_high),
            }

            payload = {
                "flows":       flows,
                "root_causes": causes,
                "signals":     signals,
            }

            await websocket.send_json(payload)
            await asyncio.sleep(2)   # match REFRESH_INTERVAL

    except WebSocketDisconnect:
        print("Client disconnected (tab closed).")
    except OSError as e:
        print(f"OS network timeout (browser lost connection): {e}")
    except Exception as e:
        print(f"Unexpected WebSocket error: {e}")


if __name__ == "__main__":
    uvicorn.run("web_daemon:app", host="127.0.0.1", port=8000, log_level="info")